"""Genera la narración femenina y el MP4 final en el equipo local.
Requiere: python -m pip install edge-tts imageio-ffmpeg
"""
import asyncio,json,subprocess,shutil,wave,io
from pathlib import Path
import edge_tts
ROOT=Path(__file__).resolve().parent
VOICE='es-MX-DaliaNeural'

def ffmpeg():
 p=shutil.which('ffmpeg')
 if p:return p
 import imageio_ffmpeg
 return imageio_ffmpeg.get_ffmpeg_exe()
FF=ffmpeg()
def run(args):subprocess.run([FF,'-y','-hide_banner','-loglevel','error',*map(str,args)],check=True)
def duration(path):
 raw=subprocess.check_output([FF,'-hide_banner','-loglevel','error','-i',str(path),'-f','s16le','-ac','1','-ar','24000','pipe:1'])
 return len(raw)/(24000*2)
async def main():
 scenes=json.loads((ROOT/'guion.json').read_text(encoding='utf-8'));work=ROOT/'locucion';work.mkdir(exist_ok=True)
 for i,scene in enumerate(scenes):
  mp3=work/f'{i:02d}.mp3';wav=work/f'{i:02d}.wav'
  print(f'Voz femenina: escena {i+1}/{len(scenes)}',flush=True)
  if not mp3.exists() or mp3.stat().st_size==0:
   try:await edge_tts.Communicate(scene['narration'],VOICE,rate='+8%',pitch='-2Hz').save(str(mp3))
   except Exception:
    mp3.unlink(missing_ok=True)
    raise RuntimeError('No se pudo conectar con el servicio de voz. Revisa la conexión y vuelve a ejecutar. No se creó un video final sin locución.')
  length=duration(mp3);speed=max(1,length/7.05)
  if speed>1.45:raise RuntimeError(f'La escena {i+1} requiere revisar el ritmo antes de entregar; no se recortó la locución.')
  run(['-i',mp3,'-af',f'atempo={speed:.6f},apad,atrim=0:7.5,afade=t=in:d=0.03,afade=t=out:st=7.35:d=0.15','-ar','48000','-ac','1',wav])
 listing=work/'lista-voz.txt';listing.write_text('\n'.join("file '%02d.wav'"%i for i in range(len(scenes))),encoding='utf-8')
 narration=ROOT/'SICOM-locucion-femenina.wav'
 run(['-f','concat','-safe','0','-i',listing,'-c:a','pcm_s16le',narration])
 output=ROOT/'SICOM-90s-vertical-VOZ-FEMENINA.mp4'
 run(['-i',ROOT/'SICOM-90s-vertical-base.mp4','-i',narration,'-filter_complex','[0:a]volume=0.20[music];[1:a]volume=1.8,alimiter=limit=0.95[voice];[music][voice]amix=inputs=2:duration=longest:normalize=0,alimiter=limit=0.97[mix]','-map','0:v:0','-map','[mix]','-c:v','copy','-c:a','aac','-b:a','192k','-t','90','-movflags','+faststart',output])
 print('\nVIDEO FINAL CON VOZ FEMENINA:\n'+str(output),flush=True)
asyncio.run(main())
